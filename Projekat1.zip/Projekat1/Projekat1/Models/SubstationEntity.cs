﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace Projekat1.Models
{
    public class SubstationEntity : PowerEntity
    {
        public SubstationEntity()
        {
            Color = Brushes.Blue;
        }
    }
}
