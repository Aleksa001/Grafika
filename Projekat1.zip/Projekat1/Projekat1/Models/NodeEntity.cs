﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace Projekat1.Models
{
    public class NodeEntity: PowerEntity
    {
        public NodeEntity()
        {
            Color = Brushes.Yellow;
        }
    }
}
